
# DonkeyFive

create userDb :

       CREATE USER 'adminDbDonkeyFive'@'localhost' IDENTIFIED BY 'password';
       GRANT ALL PRIVILEGES ON donkeyFive.* TO 'adminDbDonkeyFive'@'localhost';
       FLUSH PRIVILEGES;

Step 1 -> Create DB DonkeyFive and init projet  -> (DbDonkeyFive.Sql)
       -> CreateFolder  
