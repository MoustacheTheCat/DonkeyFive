<?php

// GLOBALS VARIABLES FOR DATABASE
define('DB_DSN', 'mysql:host=localhost; dbname=donkeyFive;');
define('DB_USER', 'adminDbDonkeyFive');
define('DB_PASS', 'password');
define('DB_OPTIONS', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));